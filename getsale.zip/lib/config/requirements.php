<?php
return array(
    'php.curl' => array(
        'name' => 'cURL',
        'description' => 'Обмен данными с серверами GetSale.io',
        'strict' => true,
    ),
    'php' => array(
        'strict' => true,
        'version' => '>=5.3',
    ),
);