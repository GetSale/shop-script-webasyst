$(document).ready(function () {
    (function (w, c) {
        w[c] = w[c] || [];
        w[c].push(function (getSale) {
            getSale.event('cat-view');
            console.log('cat-view');
        });
    })(window, 'getSaleCallbacks');
});